/**
 * A class to handle manipulating scenario examples.
 */
function ExampleManager(scenario) {
	//Store a reference to this instance since this can change.
	var self = this;

	function attachListeners() {
		var rows = self.examples.select('tbody tr.example');
		var index = 0;

		function toggleIndex(index, row) {
			//Return a function bound to this index and row to call when the click happens.
			return function() { self.toggleExample(index, row); }
		}

		$A(rows).each(function(row) {
			row.observe('click', toggleIndex(index, row));
			index++;
		});
	}

	//Manage the given scenario.
	function init(scenario) {
		self.scenario = $(scenario);
		self.main_scenario_steps = self.scenario.down('.steps');
		self.examples = self.scenario.down('.examples');
		self.expanded_scenarios = self.scenario.down('.expanded_scenario') ? true : false;
		attachListeners();
	}

	function getExpandedScenario(number) {
		return self.scenario.down("#" + self.scenario.id + "_example_" + number);
	}

	/**
	 * If an expanded scenario for the given example_number exists, perform the given action on it.
	 * (or more precisely, call the action with the expanded scenario passed in).
	 */
	function onExpandedScenario(example_number, action) {
		var expanded_scenario = getExpandedScenario(example_number).up('.expanded_scenario');
		if (expanded_scenario)
			return action(expanded_scenario);
	}

	function showExpandedScenario(example_number) {
		return onExpandedScenario(example_number, function(s){ return s.removeClassName('hidden')});
	}

	function hideExpandedScenario(example_number) {
		return onExpandedScenario(example_number, function(s){ return s.addClassName('hidden')});
	}

	//Show the given example for this scenario outline
	function showExample(example_number) {
		if (self.expanded_scenarios) {
			showExpandedScenario(example_number);
		}
		else {
			//There are no expanded scenarios...
		}
	}

	function hideExample(example_number) {
		if (self.expanded_scenarios) {
			hideExpandedScenario(example_number);
		}
		else {
			//There are no expanded scenarios...
		}
	}

	function isExampleVisible(index) {
		return onExpandedScenario(index, function(s){ return !s.hasClassName('hidden') });
	}

	function highlightRow(row) {
		$(row).addClassName('highlight');
	}

	function unhighlightRow(row) {
		$(row).removeClassName('highlight');
	}

	function toggleExample(index, row) {
		if (isExampleVisible(index)) {
			//The one we're toggling is the one that's visible, so hide it and show the original scenario.
			self.hideExample(index);
			self.unhighlightRow(row);
		}
		else {
			self.showExample(index);
			self.highlightRow(row);
		}
	}

	/********* PUBLIC INTERFACE STARTS HERE **************/
	ExampleManager.instances.push(self);

	self.showExample = showExample;
	self.hideExample = hideExample;
	self.toggleExample = toggleExample;
	self.highlightRow = highlightRow;
	self.unhighlightRow = unhighlightRow;

	init(scenario);
}
ExampleManager.instances = []


// Adds a closest-method (equivalent to the jQuery method) to all 
// extended Prototype DOM elements
// Adapted from http://stackoverflow.com/questions/2366367/prototype-equivalent-for-jquery-closest-function
Element.addMethods({
   closest: function(element, cssRule) {
      var element = $(element);
      // Return if we don't find an element to work with.
      if(!element) {
         return;
      }
      return element.match(cssRule) ? element : element.up(cssRule);
   }
});

//Static function to manage a given scenario outline.
//This will find the closest main scenario from the given element (or element id) to manage.
ExampleManager.manage = function(element) {
	scenario_element = $(element).closest('.main.scenario');
	if (!scenario_element) {
		throw "No scenario element found close to " + element;
	}
	return new ExampleManager(scenario_element);
}
